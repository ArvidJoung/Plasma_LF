
Thank you for trying C28x Software Collateral. 

V1.60 of the C280x/C2801x C/C++ Header Files and Peripheral 
By default, the software will be installed in the 
following directory:

 
C:\SynWorks\TIDCS




C2000 APPLICATIONS.
SyncWorks.Inc
