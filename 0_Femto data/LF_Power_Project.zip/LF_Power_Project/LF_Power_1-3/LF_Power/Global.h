#ifndef GLOBAL_H_
#define GLOBAL_H_

#define FLASH_LOAD		1

#define TRUE			1
#define FALSE			0

#define NULL			0

#define PID_CONTROL		FALSE

#define CTRL_FREQ		FALSE

#endif /* GLOBAL_H_ */
