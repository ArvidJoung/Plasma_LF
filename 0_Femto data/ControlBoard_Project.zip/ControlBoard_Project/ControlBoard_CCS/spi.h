/*
 * spi.h
 *
 *  Created on: 2014. 4. 25.
 *      Author: lastdkht
 */

#ifndef SPI_H_
#define SPI_H_


void Init_Spib_280x ();
Uint16 Write_Spib_280x (Uint16 Data);

#endif /* SPI_H_ */
