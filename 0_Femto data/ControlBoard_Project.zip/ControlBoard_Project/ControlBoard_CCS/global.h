/*
 * global.h
 *
 *  Created on: 2013. 2. 1.
 *      Author: lastdkht
 */

#ifndef GLOBAL_H_
#define GLOBAL_H_

#define FLASH_LOAD		1

#define TRUE			1
#define FALSE			0

#define NULL			0

#endif /* GLOBAL_H_ */
