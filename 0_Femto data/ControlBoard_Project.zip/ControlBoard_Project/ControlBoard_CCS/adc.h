/*
 * adc.h
 *
 *  Created on: 2014. 4. 25.
 *      Author: lastdkht
 */

#ifndef ADC_H_
#define ADC_H_

void Init_Adc_280x ();
void Run_Adc_280x ();
Uint16 Get_Adc_Val_280x (int id);

#endif /* ADC_H_ */
